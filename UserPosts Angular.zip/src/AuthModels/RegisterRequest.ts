export interface RegisterRequest {

    firstName: string;
    lastName: string;
    email: string;
    gender: string;
    password: string;
    passwordConfirm: string;
}