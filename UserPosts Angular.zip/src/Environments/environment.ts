export const environment ={
    isProduction: false,
    loginApiUrl: 'http://localhost:5000/auth'
}