import { Routes } from '@angular/router';
import { AuthLogin } from './auth-login/auth-login';
import { UserPosts } from './user-posts/user-posts';
import { AuthRegistration } from './auth-registration/auth-registration';
import { UsersComponent } from './users-component/users-component';
import { authGuardGuard } from './auth-guard-guard';

export const routes: Routes = [
    {   path: 'login',
        component: AuthLogin
    },

    {
        path:'register',
        component: AuthRegistration
    },

    {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
    },

    {
        path: 'allPosts',
        component: UserPosts
    },

   
    {
        path: 'userManagement',
        component: UsersComponent,
        canActivate: [authGuardGuard]
    },
    
     {
        path: '**',
        redirectTo: 'login'
    },


    
];
