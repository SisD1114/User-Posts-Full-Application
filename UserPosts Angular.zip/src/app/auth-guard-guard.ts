import { CanActivateFn,Router } from '@angular/router';
import { inject } from '@angular/core';
import { Auth } from './auth';

export const authGuardGuard: CanActivateFn = () => {

  const authService = inject(Auth);
  const router = inject(Router);
  

  if (authService.isLoggedIn())
  {
    return true;
  }
  return router.createUrlTree(['/login']);
};
