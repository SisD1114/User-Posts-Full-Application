
import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {

  // Do not attach a token to the login or User API requests.
  if (
    req.url.endsWith('auth/login') ||
    req.url.startsWith('http://localhost:5000/User/')
  ) {
    return next(req);
  }

  const token = sessionStorage.getItem('jwt');

  if (!token) {
    return next(req);
  }

  const authReq = req.clone({
    setHeaders: {
      Authorization: `Bearer ${token}`
    }
  });

  return next(authReq);
};
