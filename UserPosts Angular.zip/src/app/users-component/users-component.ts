
import {
  Component,
  OnInit,
  ChangeDetectorRef,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { UserService } from '../user-service';
import { User } from '../UserModels/User';

@Component({
  selector: 'app-users-component',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './users-component.html',
  styleUrl: './users-component.css'
})
export class UsersComponent implements OnInit {

  users: User[] = [];

  user: User = this.emptyUser();

  showForm = false;
  isEdit = false;

  isLoading = false;
  isSaving = false;

  errorMessage = '';

  private cdr = inject(ChangeDetectorRef);

  constructor(private userService: UserService) {}

  // Load users automatically when the page opens
  ngOnInit(): void {
    this.loadUsers();
  }

  // Empty user object
  emptyUser(): User {
    return {
      userId: 0,
      firstName: '',
      lastName: '',
      email: '',
      gender: '',
      active: true
    };
  }

  // Get users from API
 

loadUsers(): void {

  console.log('Loading users...');

  this.isLoading = true;
  this.errorMessage = '';

  this.userService.getUsers(0, false).subscribe({

    next: (response: User[]) => {

      console.log('API returned:', response);

      this.users = response ?? [];

      this.isLoading = false;

      console.log('Users loaded:', this.users.length);

      // Force Angular to update the view
      this.cdr.detectChanges();

    },

    error: (error) => {

      console.error('Error loading users:', error);

      this.errorMessage = 'Unable to load users.';

      this.isLoading = false;

      this.cdr.detectChanges();

    }

  });

}



  // Open modal for adding a user
  addUser(): void {

  this.user = this.emptyUser();

  this.isEdit = false;

  this.showForm = true;

  this.cdr.detectChanges();

}

  // Open modal for editing a user
  editUser(selectedUser: User): void {

    this.user = { ...selectedUser };

    this.isEdit = true;

    this.showForm = true;

  }

  // Save user
  saveUser(): void {

    if (this.isSaving) {
      return;
    }

    this.isSaving = true;

    this.userService.upsertUser(this.user).subscribe({

      next: () => {

        alert(this.isEdit
          ? 'User updated successfully!'
          : 'User added successfully!');

        this.showForm = false;

        this.isSaving = false;

        this.loadUsers();

      },

      error: (error) => {

        console.error('Error saving user:', error);

        alert('Failed to save user.');

        this.isSaving = false;

      }

    });

  }

  // Delete user
  deleteUser(userId: number): void {

    if (!confirm('Are you sure you want to delete this user?')) {
      return;
    }

    this.userService.deleteUser(userId).subscribe({

      next: () => {

        alert('User deleted successfully!');

        this.loadUsers();

      },

      error: (error) => {

        console.error('Error deleting user:', error);

        alert('Failed to delete user.');

      }

    });

  }

  // Close modal
  cancel(): void {

    this.showForm = false;

    this.user = this.emptyUser();

  }

}
