import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { User } from './UserModels/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private http = inject(HttpClient);

  private apiUrl = 'http://localhost:5000/User';

  getUsers(userId: number = 0, isActive: boolean = false): Observable<User[]> {
    return this.http.get<User[]>(
      `${this.apiUrl}/GetUsers/${userId}/${isActive}`
    );
  }

  upsertUser(user: User): Observable<void> {
    return this.http.put<void>(
      `${this.apiUrl}/UpsertUser`,
      user
    );
  }

  deleteUser(userId: number): Observable<void> {
    return this.http.delete<void>(
      `${this.apiUrl}/DeleteUser/${userId}`
    );
  }
}