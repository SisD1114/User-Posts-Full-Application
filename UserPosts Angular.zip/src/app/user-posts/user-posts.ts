import {
  Component,
  OnInit,
  inject,
  ChangeDetectorRef
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';

import { PostService } from '../post-service';
import { Auth } from '../auth';
import { Post } from '../PostModels/Post';
import { PostToAdd } from '../PostModels/PostToAdd';

@Component({
  imports: [CommonModule, FormsModule],
  selector: 'app-user-posts',
  styleUrl: './user-posts.css',
  templateUrl: './user-posts.html',
})
export class UserPosts implements OnInit {

  private readonly postService = inject(PostService);
  private readonly authService = inject(Auth);
  private readonly cdr = inject(ChangeDetectorRef);

  posts: Post[] = [];

  loading = true;
  errorMessage = '';
  successMessage = '';

  currentView: 'all' | 'mine' = 'all';

  showAddPostModal = false;
  editingPostId: number | null = null;

  myPostIds = new Set<number>();

  savingPost = false;

  newPost: PostToAdd = {
    postTitle: '',
    postContent: ''
  };


  // INITIALISE COMPONENT
  ngOnInit(): void {

    if (!this.authService.isLoggedIn()) {

      this.errorMessage =
        'You need to log in to view posts';

      this.loading = false;

      this.authService.logout();

      return;
    }

    this.loadPosts();
  }


  // LOAD ALL POSTS
  loadPosts(): void {

    this.currentView = 'all';
    this.loading = true;
    this.errorMessage = '';

    forkJoin({

      allPosts: this.postService.getPosts(),

      myPosts: this.postService.getMyPosts()

    }).subscribe({

      next: (data) => {

        // Load all posts
        this.posts = data.allPosts;

        // Identify posts belonging to the logged-in user
        this.myPostIds = new Set(
          data.myPosts.map(post => post.postId)
        );

        this.loading = false;

        this.cdr.markForCheck();
      },

      error: (error) => {

        this.handlePostError(error);

      }

    });
  }


  // LOAD MY POSTS
  loadMyPosts(): void {

    this.currentView = 'mine';
    this.loading = true;
    this.errorMessage = '';

    this.postService.getMyPosts().subscribe({

      next: (data: Post[]) => {

        this.posts = data;

        // Update IDs of my posts
        this.myPostIds = new Set(
          data.map(post => post.postId)
        );

        this.loading = false;

        this.cdr.markForCheck();
      },

      error: (error) => {

        this.handlePostError(error);

      }

    });
  }


  // HANDLE API ERRORS
  private handlePostError(error: any): void {

    this.loading = false;

    if (error.status === 401) {

      this.errorMessage =
        'Your session has expired. Please log in again.';

      this.authService.logout();

    } else if (error.status === 403) {

      this.errorMessage =
        'You are not authorized to view these posts.';

    } else {

      this.errorMessage =
        'Unable to load posts. Please try again later.';

    }

    this.cdr.markForCheck();

    console.error('Error loading posts:', error);
  }


  // LOGOUT
  logout(): void {

    this.authService.logout();

  }


  // CHECK IF POST BELONGS TO LOGGED-IN USER
  canEditPost(post: Post): boolean {

    return this.myPostIds.has(post.postId);

  }


  // OPEN ADD POST MODAL
  openAddPostModal(): void {

    this.editingPostId = null;

    this.newPost = {
      postTitle: '',
      postContent: ''
    };

    this.errorMessage = '';
    this.successMessage = '';

    this.showAddPostModal = true;
  }


  // EDIT EXISTING POST
  editPost(post: Post): void {

    // Prevent editing posts that do not belong to the user
    if (!this.canEditPost(post)) {
      return;
    }

    // Store the existing post ID
    this.editingPostId = post.postId;

    // Populate the form with existing post details
    this.newPost = {
      postTitle: post.postTitle,
      postContent: post.postContent
    };

    this.errorMessage = '';
    this.successMessage = '';

    this.showAddPostModal = true;
  }


  // CLOSE ADD/EDIT MODAL
  closeAddPostModal(): void {

    if (this.savingPost) {
      return;
    }

    this.showAddPostModal = false;

    this.editingPostId = null;

    this.newPost = {
      postTitle: '',
      postContent: ''
    };

    this.errorMessage = '';
  }


  // CREATE OR UPDATE POST
  addPost(): void {

    // Validate form
    if (
      !this.newPost.postTitle.trim() ||
      !this.newPost.postContent.trim()
    ) {

      this.errorMessage =
        'Please enter a title and post content.';

      return;
    }

    this.savingPost = true;

    this.errorMessage = '';
    this.successMessage = '';

    // Determine whether we are editing or creating
    const wasEditing = this.editingPostId !== null;

    // Prepare post data
    const postToAdd: PostToAdd = {

      postTitle: this.newPost.postTitle.trim(),

      postContent: this.newPost.postContent.trim()

    };

    // Send existing post ID when editing.
    // Send null when creating a new post.
    this.postService.upsertPost(
      postToAdd,
      this.editingPostId
    ).subscribe({

      next: () => {

        this.savingPost = false;

        this.successMessage = wasEditing
          ? 'Post updated successfully!'
          : 'Post created successfully!';

        // Close modal
        this.showAddPostModal = false;

        // Reset editing ID
        this.editingPostId = null;

        // Clear form
        this.newPost = {
          postTitle: '',
          postContent: ''
        };

        // Refresh currently selected view
        if (this.currentView === 'mine') {

          this.loadMyPosts();

        } else {

          this.loadPosts();

        }

        this.cdr.markForCheck();

      },

      error: (error) => {

        this.savingPost = false;

        if (error.status === 401) {

          this.errorMessage =
            'Your session has expired. Please log in again.';

          this.authService.logout();

        } else if (error.status === 403) {

          this.errorMessage =
            'You are not authorized to save this post.';

        } else if (error.status === 404) {

          this.errorMessage =
            'The post could not be found.';

        } else {

          this.errorMessage =
            'Unable to save the post. Please try again.';

        }

        console.error('Error saving post:', error);

        this.cdr.markForCheck();

      }

    });

  }

   // DELETE POST
  deletePost(post: Post): void {

    // Check that the post belongs to the logged-in user
    if (!this.canEditPost(post)) {
      this.errorMessage =
        'You are not authorized to delete this post.';
      return;
    }

    // Ask for confirmation before deleting
    const confirmed = window.confirm(
      `Are you sure you want to delete "${post.postTitle}"?`
    );

    if (!confirmed) {
      return;
    }

    this.errorMessage = '';
    this.successMessage = '';

    this.postService.deletePost(post.postId).subscribe({

      next: () => {

        this.successMessage =
          'Post deleted successfully!';

        // Remove the deleted post from the local array
        this.posts = this.posts.filter(
          p => p.postId !== post.postId
        );

        // Remove the ID from the user's post IDs
        this.myPostIds.delete(post.postId);

        this.cdr.markForCheck();

      },

      error: (error) => {

        if (error.status === 401) {

          this.errorMessage =
            'Your session has expired. Please log in again.';

          this.authService.logout();

        } else if (error.status === 403) {

          this.errorMessage =
            'You are not authorized to delete this post.';

        } else if (error.status === 404) {

          this.errorMessage =
            'The post could not be found.';

        } else {

          this.errorMessage =
            'Unable to delete the post. Please try again.';

        }

        console.error('Error deleting post:', error);

        this.cdr.markForCheck();

      }

    });

  }


}