
import { Injectable, inject } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { LoginRequest } from '../AuthModels/LoginRequest';
import { LoginResponse } from '../AuthModels/LoginResponse';
import { HttpClient } from '@angular/common/http';
import { RegisterRequest } from '../AuthModels/RegisterRequest';


@Injectable({
  providedIn: 'root'
})
export class Auth {
  private http = inject(HttpClient);

  private readonly apiUrl = 'http://localhost:5000/auth';

login(credentials: LoginRequest): Observable<LoginResponse> {
    return this.http
      .post<LoginResponse>(
        `${this.apiUrl}/login`,
        credentials
      )
      .pipe(
        tap(response => {
          sessionStorage.setItem('jwt', response.token);
        })
      );
  }
    getToken(): string | null {
      return sessionStorage.getItem('jwt');
    }

    isLoggedIn(): boolean {
      return !!this.getToken();
    }

    logout(): void {
      sessionStorage.removeItem('jwt');
    }

 register(
    user: RegisterRequest
  ): Observable<void> {

    return this.http.post<void>(
      `${this.apiUrl}/register`,
      user
    );
  }
}