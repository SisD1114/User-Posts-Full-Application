import { Component, signal } from '@angular/core';
import { RouterModule, RouterOutlet } from '@angular/router';

import { UserPosts } from './user-posts/user-posts';
import { Navbar } from './navbar/navbar';

@Component({
  selector: 'app-root',
  standalone: true,

  imports: [
    RouterOutlet,
    RouterModule,
    UserPosts,
    Navbar
  ],

  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly title = signal('UserPost-App');
}
