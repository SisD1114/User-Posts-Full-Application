import { Service } from '@angular/core';
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Post } from './PostModels/Post';
import { PostToAdd } from './PostModels/PostToAdd';

@Injectable({
    providedIn: 'root'
})
export class PostService {
    private readonly http = inject(HttpClient);

    private readonly apiUrl = 'http://localhost:5000/post';

    // GET ALL POSTS
    getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(
      `${this.apiUrl}/Posts/0/0/None`
    );
  }

   // GET POSTS BELONGING TO THE LOGGED-IN USER
  getMyPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(
      `${this.apiUrl}/MyPosts`
    );
  }

  // CREATE OR UPDATE A POST
  upsertPost(
    post: PostToAdd,
    postId: number | null = null
  ): Observable<void> {

    const postToUpsert = {
      postId: postId ?? 0,
      postTitle: post.postTitle,
      postContent: post.postContent
    };

    return this.http.put<void>(
      `${this.apiUrl}/UpsertPost`,
      postToUpsert
    );
  }

   // DELETE POST
  deletePost(postId: number): Observable<void> {
    return this.http.delete<void>(
      `${this.apiUrl}/Post/${postId}`
    );
  }

}
