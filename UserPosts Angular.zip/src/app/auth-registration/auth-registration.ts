import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  Validators
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize } from 'rxjs';
import { Auth } from '../auth';
import { RegisterRequest } from '../../AuthModels/RegisterRequest';

function passwordMatchValidator(
  control: AbstractControl
): ValidationErrors | null {
  const password = control.get('password')?.value;
  const passwordConfirm = control.get('passwordConfirm')?.value;

  if (!password || !passwordConfirm) {
    return null;
  }

  return password === passwordConfirm
    ? null
    : { passwordMismatch: true };
}


@Component({
  imports: [CommonModule,ReactiveFormsModule,RouterLink],
  selector: 'app-auth-registration',
  styleUrl: './auth-registration.css',
  templateUrl: './auth-registration.html',
})
export class AuthRegistration {

  private fb = inject(FormBuilder);
  private auth = inject(Auth);
  private router = inject(Router);

  isSubmitting = false;
  loading = false;
  successMessage = '';
  errorMessage = '';

  registerForm = this.fb.group(
    {
      firstName: [
        '',
        [Validators.required, Validators.maxLength(100)]
      ],
      lastName: [
        '',
        [Validators.required, Validators.maxLength(100)]
      ],
      email: [
        '',
        [Validators.required, Validators.email]
      ],
      gender: ['', Validators.required],
      password: [
        '',
        [Validators.required, Validators.minLength(8)]
      ],
      passwordConfirm: ['', Validators.required]
    },
    {
      validators: passwordMatchValidator
    }
  );

    constructor(
      private fbc: FormBuilder,
      private authService: Auth
      ) {}

  get f() {
    return this.registerForm.controls;
  }

 onSubmit(): void {
    this.successMessage = '';
    this.errorMessage = '';

    if (this.registerForm.invalid) {
      this.registerForm.markAllAsTouched();
      return;
    }

    const request: RegisterRequest ={
       firstName: this.f.firstName.value!,
      lastName: this.f.lastName.value!,
      email: this.f.email.value!,
      gender: this.f.gender.value!,
      password: this.f.password.value!,
      passwordConfirm: this.f.passwordConfirm.value!
    };

    this.isSubmitting = true;
    

    this.auth.register(request)
      .subscribe({
        next: () => {
        this.successMessage = 'Registration successful!';
        this.registerForm.reset();
        this.isSubmitting = false;
        },
        error: (error) => {
        this.isSubmitting = false;

        if (error.status === 0) {
          this.errorMessage =
            'Unable to connect to the server. Please try again.';
        } else if (error.status === 409) {
          this.errorMessage =
            'An account with this email already exists.';
        } else if (error.status === 400) {
          this.errorMessage =
            error.error?.message || 'Please check your registration details.';
        } else {
          this.errorMessage =
            error.error?.message ||
            'Registration failed. Please try again.';
        }

          console.error('Registration error:', error);
        }
      });
  }

}
