import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AuthRegistration } from './auth-registration';

describe('AuthRegistration', () => {
  let component: AuthRegistration;
  let fixture: ComponentFixture<AuthRegistration>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AuthRegistration],
    }).compileComponents();

    fixture = TestBed.createComponent(AuthRegistration);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
