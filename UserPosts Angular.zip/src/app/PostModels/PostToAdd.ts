export interface PostToAdd{
    postTitle:string;
    postContent: string;
}