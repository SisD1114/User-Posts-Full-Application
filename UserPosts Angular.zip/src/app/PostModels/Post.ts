export interface Post{
    postId: number;
    userId: number;
    postTitle:string;
    postContent: string;
    postCreated: string;
    postUpdated:string;
}