using Dapper;
using Microsoft.AspNetCore.Mvc;
using UserPosts.Data;
using UserPosts.Helpers;
using UserPosts.Models;
using System.Data;

namespace UserPosts.Controllers;
    
[ApiController]
[Route("[controller]")]
public class UserController:ControllerBase
{
       private readonly DataContextDapper _dapper;
       private readonly ReusableSql _reusableSql;
        public UserController(IConfiguration config)
        {
           _dapper = new DataContextDapper(config);
           _reusableSql = new ReusableSql(config);
        }


[HttpGet("TestConnection")]

public DateTime TestConnection()
        {
            return _dapper.LoadDataSingle<DateTime>("SELECT GETDATE()");
        }


[HttpGet("GetUsers/{userId}/{isActive}")]

public IEnumerable<User> GetUser(int userId, bool isActive)
        {
                string sql = @"EXEC UserPostsSchema.spUsers_Get";
                string stringParameters = "";
                DynamicParameters sqlParamenters = new DynamicParameters();


                if (userId != 0)
            {
                stringParameters += ", @UserId = @UserIdParameter";
                sqlParamenters.Add("@UserIdParameter", userId, DbType.Int32);
            }

            if (isActive)
            {
                stringParameters += ", @Active =@ActiveParameter"; 
                sqlParamenters.Add("@ActiveParameter", isActive, DbType.Boolean);
            }

            if (stringParameters.Length >0)
            {
                sql += stringParameters.Substring(1);
                
            }   

             IEnumerable<User> users = _dapper.LoadDataWithParameters<User>(sql, sqlParamenters);
             return users;
        }

[HttpPut("UpsertUser")]

public IActionResult UpsertUser(User user)
        {
                if(_reusableSql.UpsertUser(user)) 
                {
                return Ok();
                }
                throw new Exception ("Failed to Upsert user");
                
        }


[HttpDelete ("DeleteUser/{userId}")] 

public IActionResult DeleteUser (int userId)
    {
        string sql = @"UserPostsSchema.spUser_Delete
        @UserId = @UserIdParameter";

        DynamicParameters sqlParameters = new DynamicParameters();
        sqlParameters.Add("@UserIdParameter", userId, DbType.Int32);
        
        if(_dapper.ExecuteSqlWithParameters(sql, sqlParameters))
        {
            return Ok();
        }
        throw new Exception ("Failed to delete user");
    }
}