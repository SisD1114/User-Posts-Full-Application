using System.Data;
using AutoMapper;
using Dapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using UserPosts.Data;
using UserPosts.Dtos;
using UserPosts.Helpers;
using UserPosts.Models;

namespace UserPosts.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]

    public class AuthController: ControllerBase
    {
        private readonly DataContextDapper _dapper;
            private readonly IConfiguration _config;
            private readonly AuthHelper _authHelper;
            private readonly ReusableSql _reusableSql;
            private readonly IMapper _mapper;
            public AuthController(IConfiguration config)
            {
                _dapper = new DataContextDapper(config);
                _config = config;
                _authHelper = new AuthHelper(config);
                _reusableSql = new ReusableSql(config);
                _mapper = new Mapper (new MapperConfiguration (cfg =>
                {
                    cfg.CreateMap<UserForRegistrationDto, User>();
                },NullLoggerFactory.Instance));
            }

    [AllowAnonymous]
    [HttpPost ("Register")]
            public IActionResult Register(UserForRegistrationDto userForRegistration)
            {
                if (userForRegistration.Password == userForRegistration.PasswordConfirm)
                {

                string sqlCheckUserExists = "SELECT Email FROM UserPostsSchema.Auth WHERE Email = '" +
                        userForRegistration.Email + "'";

                    IEnumerable<string> existingUsers = _dapper.LoadData<string>(sqlCheckUserExists);
                    if (existingUsers.Count() == 0)
                    {

                        UserForLoginDto userForSetPassword = new UserForLoginDto()
                        {  Email = userForRegistration.Email,
                        Password = userForRegistration.Password  };
                    
                        if (_authHelper.SetPassword(userForSetPassword))
                        {
                            User user = _mapper.Map<User>(userForRegistration);
                            user.Active = true;

                            if (_reusableSql.UpsertUser(user)) 
                                { 
                                return Ok();
                                }
                            throw new Exception("Failed to add user");
                            
                        }
                    throw new Exception("failed to register user");
                    }
                    throw new Exception ("User already exists");
                    
                }
                throw new Exception ("Passwords do not match");
                
            }

    [HttpPut("ResetPassword")]

        public IActionResult ResetPassword(UserForLoginDto userForSetPassword)
            {
                if (_authHelper.SetPassword(userForSetPassword))
                {
                    return Ok();
                }
                throw new Exception("Failed to update password");
            }
            
    [AllowAnonymous]
    [HttpPost ("Login")]
            public IActionResult Login(UserForLoginDto userForLogin)
            {
                string sqlForHashAndSalt = @"EXEC UserPostsSchema.spLoginConfirmation_Get @Email = @EmailParam";
            
            DynamicParameters sqlParameters = new DynamicParameters();

                sqlParameters.Add("@EmailParam", userForLogin.Email, DbType.String);

                UserForLoginConfirmationDto userForConfirmation = _dapper.LoadDataSingleWithParameters
                <UserForLoginConfirmationDto>(sqlForHashAndSalt, sqlParameters);

                byte[] passwordHash = _authHelper.GetPasswordHash(userForLogin.Password, userForConfirmation.PasswordSalt);

                for (int index = 0; index < passwordHash.Length; index ++)
                {
                    if (passwordHash [index] != userForConfirmation.PasswordHash[index])
                    {
                        return StatusCode (401, "Incorrect Password");
                    } 
                }
                string userIdSql = @"
                    SELECT UserId FROM UserPostsSchema.Users WHERE Email = '" + 
                    userForLogin.Email + "'";
                        
                int userId = _dapper.LoadDataSingle<int>(userIdSql);
                var tokenData = _authHelper.CreateToken(userId);

                    return Ok(new 
                    {
                        token = tokenData.Token,
                        expiration =tokenData.ExpiresAt
                    });
            }

    [HttpGet ("RefreshToken")]

            public IActionResult RefreshToken()
            {
                string userIdSql = @"
                SELECT UserId FROM TutorialAppSchema.Users WHERE UserId = '" + 
                User.FindFirst("userId")?.Value + "'";

                int userId = _dapper.LoadDataSingle<int>(userIdSql);
            
                var tokenData = _authHelper.CreateToken(userId);

                return Ok(new
                {
                    token = tokenData.Token,
                    expiration = tokenData.ExpiresAt
                });
            }


    }
}