using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Dapper;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.IdentityModel.Tokens;
using UserPosts.Data;
using UserPosts.Dtos;

namespace UserPosts.Helpers
{
    public class AuthHelper
    {
        private readonly IConfiguration _config;
        private readonly DataContextDapper _dapper;
        
        public AuthHelper(IConfiguration config)
        {
            _dapper = new DataContextDapper(config);
            _config = config;
        }


        public byte[] GetPasswordHash(string password, byte[] passwordSalt)
        {
            string passwordSaltPlusString = _config.GetSection("AppSettings:PasswordKey").Value + 
            Convert.ToBase64String(passwordSalt);

            return KeyDerivation.Pbkdf2(
            password:password,
            salt: Encoding.ASCII.GetBytes(passwordSaltPlusString),
            prf: KeyDerivationPrf.HMACSHA256,
            iterationCount:100000,
            numBytesRequested:256 / 8

            );
        }
        public (string Token, DateTime ExpiresAt) CreateToken(int userId)
        {
           Claim[] claims = new Claim[]
           {
               new Claim("userId",userId.ToString())
           };

          
           string? tokenKeyString = _config.GetSection("AppSettings:TokenKey").Value;

            SymmetricSecurityKey tokenKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(
            tokenKeyString != null ? tokenKeyString : ""
            ));

        SigningCredentials credentials = new SigningCredentials
            (tokenKey, 
            SecurityAlgorithms.HmacSha512Signature);

        DateTime expiresAt = DateTime.Now.AddDays(1);

        SecurityTokenDescriptor descriptor = new SecurityTokenDescriptor()
        {
            Subject = new ClaimsIdentity(claims),
            SigningCredentials = credentials,
            Expires = expiresAt
        };

        JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();

        SecurityToken token = tokenHandler.CreateToken(descriptor);

        string jwt = tokenHandler.WriteToken(token);

        return (jwt, expiresAt);
        
        }
        public bool SetPassword(UserForLoginDto userForSetPassword)
        {
            
            byte[] passwordSalt = new byte[128 / 8];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                rng.GetNonZeroBytes(passwordSalt);
            }

            byte[] passwordHash = GetPasswordHash(userForSetPassword.Password, passwordSalt);

            string sqlAddAuth = @"EXEC UserPostsSchema.spRegistration_Upsert
                @Email = @EmailParam,
                @PasswordHash = @PasswordHashParam, 
                @PasswordSalt = @PasswordSaltParam";
                DynamicParameters sqlParameters = new DynamicParameters();


                sqlParameters.Add("@EmailParam", userForSetPassword.Email, DbType.String);
                sqlParameters.Add("@PasswordHashParam", passwordHash, DbType.Binary);
                sqlParameters.Add("@PasswordSaltParam", passwordSalt, DbType.Binary);
    
            return _dapper.ExecuteSqlWithParameters(sqlAddAuth,sqlParameters);
                    
        }
    }
}