using Microsoft.EntityFrameworkCore;
using UserPosts.Models;

namespace UserPosts.Data
{
    public class DataContextEF:DbContext
    {
        private readonly IConfiguration _config;
        public DataContextEF(IConfiguration config)
        {
            _config = config;
        }
                public virtual DbSet<User> Users {get; set;}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_config.GetConnectionString("DefaultConnection"),optionsBuilder => optionsBuilder.EnableRetryOnFailure());

            }
        
        }

        //telling EF where the schema is
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("UserPostsSchema");
            modelBuilder.Entity<User>()
                .ToTable ("Users", "UserPostsSchema")
                .HasKey(u => u.UserId);
        }
    }
}