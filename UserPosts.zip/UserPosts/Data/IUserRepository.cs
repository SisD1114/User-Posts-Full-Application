using UserPosts.Models;

namespace UserPosts.Data
{
    public interface IUserRepository
    {
        public bool SaveChanges();
        public void AddEntity<T>(T entityToAdd);
        public void RemoveEntity<T>(T entityToRemove);
        
        public IEnumerable<User> GetUser();
        public User GetSingleUser(int userId);
    }
}